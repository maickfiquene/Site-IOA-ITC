# Prompt: aba "Nossos Professores"

```
Adicione a página "Nossos Professores" (professores.html) ao site existente. ANTES de codar, leia só a estrutura atual (lista de arquivos, css/tokens.css, js/layout.js e o padrão de cards/animações já usados) e reaproveite componentes, cores e tipografia. Não altere páginas nem funções existentes além de: item "Professores" no menu/rodapé (layout.js) e, se houver, a lista de cursos em data.js (veja abaixo).

Dados: data/professores.json (já pronto, com fotos em assets/img/professores/). Converta para o formato de dados do projeto (ex.: js/professores-data.js) mantendo os mesmos campos. Não invente nada: nenhum cargo, currículo ou especialidade.

Regras:
- Agrupar por curso (cursos[]), com título de seção e contagem. Filtro/âncoras por curso no topo (chips), "Todos" por padrão.
- Card: foto (proporção 4:5, object-fit cover), nome (campo titulo + nome), curso. Sem foto (foto=null): placeholder elegante com iniciais sobre fundo da paleta, para trocar depois só preenchendo "foto".
- status "confirmado": aparece no(s) curso(s) de cursos[]. "conflito": aparece no curso de cursos[]; cursosAConfirmar NÃO gera grupo (só fica no dado). "fora-da-lista": aparece normalmente no curso. "curso-pendente": grupo final "Curso a confirmar".
- Daniel Coelho de Carvalho (2 cursos): um cadastro, aparece nos dois grupos.
- Não exibir o campo nota, registro profissional (CRO) nem currículo.
- Flag CFG.mostrarDocentes: se false, a página mostra aviso "em breve" em vez dos cards (deixe true no protótipo).
- Animações sutis: reveal ao rolar com stagger, hover com leve elevação; respeitar prefers-reduced-motion; só transform/opacity.
- Responsivo: 1 coluna até 480px, 2 até 900, 3-4 no desktop. Cabeçalho de seção legível no celular.
- A11y: alt "Foto de <nome>", foco visível, h1 único, h2 por curso.
- SEO: title/description próprios, entrada no sitemap.
- Cursos: acrescente "Implantodontia" ao catálogo de especializações se ainda não existir (apenas título e área, sem preço, data ou carga horária). Odontopediatria e Prótese/Periodontia já existem.

Resposta final: no máximo 6 linhas.
```
