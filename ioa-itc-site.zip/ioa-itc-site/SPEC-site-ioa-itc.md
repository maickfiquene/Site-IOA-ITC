# SPEC · Site de teste IOA/ITC São Luís (HTML estático) · v2

> Esta pasta já contém tudo: a spec, as fotos em `assets/img/` e o protótipo antigo em `referencia/` (só referência visual).
> Prompt para o Claude Code: **"Leia SPEC-site-ioa-itc.md por inteiro e implemente seguindo a seção 17. Pare ao fim de cada etapa para eu revisar."**

---

## 1. Objetivo e escopo

Site institucional e comercial de teste do IOA/ITC São Luís, em **HTML, CSS e JavaScript puros**, abrindo direto no navegador (ou Live Server), **sem build, sem frameworks e sem backend**.

É a simulação da **Fase 1**: informar, qualificar o interesse e levar o visitante ao WhatsApp. O que seria backend (CMS, leads) é simulado com `localStorage` e identificado como simulação.

**Dentro:** páginas públicas, **catálogo das especializações com filtros**, página de cada especialização, **aba Estrutura com galeria**, formulário com filtro de qualificação, chatbot por regras com handoff ao WhatsApp, painel simulado, LGPD, SEO, acessibilidade e mobile próprio.

**Fora (Fases 2 e 3):** pagamento, CRM real, portal do aluno, agendamento de pacientes, login, envio real de e-mail.

---

## 2. Contexto do cliente

- **IOA** (Instituto Orofacial das Américas): rede de educação em saúde orofacial, Grupo Kefraya.
- **ITC** (Instituto de Treinamento em Cadáveres): treinamento avançado com cadáveres frescos para profissionais da saúde.
- **Universidade Ceuma:** parceira da iniciativa em São Luís.
- Posicionamento publicado pela unidade: "a maior Rede Premium em Educação Orofacial e o maior Instituto de Treinamento em Cadáveres Frescos das Américas".
- **Unidade:** R. Carutapera, 5, Jardim Renascença, São Luís – MA, 65075-670.
- **Públicos:** profissionais da saúde (sobretudo cirurgiões-dentistas) que buscam especialização; pacientes da clínica (aulas práticas e Odontologia premium).

**Problemas que o site resolve:** sem link próprio para cursos; divulgação só por redes e indicações; leads sem qualificação consomem a equipe no WhatsApp; CRM só cadastra alunos.

---

## 3. Regra de ouro: só conteúdo real

1. **Usar apenas** dados das seções 6 e 8, que vêm de materiais oficiais da unidade (posts, stories, folder, textos institucionais).
2. **Não existe** no site: preço, parcelamento, carga horária, datas de turma, número de vagas, programa por módulos, depoimentos, nota de avaliação, quantidade de alunos da unidade. Nada disso foi fornecido.
3. Onde faltar dado, mostrar **"Consulte a equipe"** com botão de WhatsApp. **Nunca** inventar nem usar "exemplo".
4. **Certificação:** só a frase oficial da seção 6. Não afirmar quem emite o certificado de cada curso.
5. **Pessoas:** não usar fotos de docentes nem de pessoas. Nomes de docentes só como lista textual, marcada "divulgados nas redes da unidade · publicar após autorização" (seção 8).
6. Peças anatômicas humanas: tom **sóbrio e respeitoso**.
7. Português do Brasil.

---

## 4. Estrutura de pastas

```
ioa-itc-site/
├── index.html
├── especializacoes.html      (catálogo)
├── especializacao.html       (lê ?slug=)
├── treinamento-itc.html
├── estrutura.html            (NOVA · galeria)
├── clinica.html
├── institucional.html
├── contato.html
├── privacidade.html
├── admin.html                (painel simulado, noindex)
├── 404.html
├── css/   tokens.css · base.css · components.css · pages.css
├── js/    config.js · data.js · layout.js · catalog.js · course.js · gallery.js
│          forms.js · chatbot.js · admin.js · ui.js
├── assets/img/               (fotos e logo, ver seção 5)
├── referencia/               (protótipo antigo; não copiar dados dele)
└── README.md
```

`layout.js` injeta header e footer a partir de uma única fonte (`<div id="site-header">` / `<div id="site-footer">`).
**Atenção:** o protótipo em `referencia/` contém cursos e valores inventados. Usar só como referência de visual.

---

## 5. Identidade visual e imagens

### Cores (`tokens.css`)
`--navy #0c1c45` · `--navy-2 #13295f` · `--royal #1f4fb2` · `--gold #9c7d33` · `--gold-2 #c3a35c` · `--gold-soft #f7f1e3` · `--green #2e9c48` · `--green-soft #e7f5eb` · `--ink #111827` · `--muted #5b6475` · `--line #e3e6ed` · `--paper #f6f7f9`.
Azul = institucional, **dourado = IOA/Odontologia/clínica**, **verde = ITC**.

### Tipografia
**Outfit** (Google Fonts, 300–700). Títulos peso 500; rótulos pequenos em caixa alta com espaçamento largo; corpo mínimo 16px.

### Elementos
Fundo com **linhas diagonais finas** (135°) como nos posts; **pílula dourada** com o endereço; faixa verde de 4px acima do rodapé; cantos 10–16px; animações sutis (respeitar `prefers-reduced-motion`).

### Logo
`assets/img/logo.png` (IOA | ITC · São Luís – MA). Em fundo escuro, usar **placa branca arredondada** (letras pretas).

### Fotos disponíveis (`assets/img/`) e onde usar
| Arquivo | Conteúdo | Categoria na galeria | Uso sugerido |
|---|---|---|---|
| `fachada-noturna.jpg` | Fachada iluminada à noite, "Instituto Orofacial das Américas" | Fachada | **Hero da Home**, página Contato |
| `recepcao.jpg` (vertical) | Recepção com logos ITC e IOA | Recepção | Institucional, Home (bloco de boas-vindas) |
| `laboratorio-itc.jpg` | Laboratório com macas inox e focos cirúrgicos | Laboratório ITC | **Treinamento ITC (hero)**, Home (bloco ITC) |
| `auditorio-itc.jpg` | Auditório com logo ITC | Auditório | Treinamento ITC, Estrutura |
| `sala-aula-ioa-1.jpg` | Sala de aula, bancadas e logo IOA | Salas de aula | Especializações (cabeçalho), Estrutura |
| `sala-aula-ioa-2.jpg` | Sala de aula, painel de madeira com logo IOA | Salas de aula | Página de especialização, Estrutura |
| `sala-reuniao.jpg` | Sala de reuniões | Espaços de apoio | Institucional, Estrutura |
| `clinica-odonto-1.jpg` | Clínica/laboratório odontológico com cadeiras | Clínica | **Clínica (hero)**, Home |
| `clinica-odonto-2.jpg` | Mesmo ambiente com iluminação azul/roxa | Clínica | Clínica, Estrutura |
| `cadeira-odonto.jpg` (vertical) | Cadeira odontológica, tela IOA | Clínica | Clínica (cartão), Estrutura |
| `detalhe-bancada.jpg` | Detalhe da bancada com instrumentais | Detalhes | Estrutura, fundo de seções |

Regras: `alt` descritivo, `loading="lazy"` (exceto o hero), `width`/`height` explícitos, `object-fit: cover` com `object-position` ajustado, e **overlay navy** quando houver texto sobre foto. As verticais (`recepcao`, `cadeira-odonto`) ficam em cartões altos, nunca esticadas.

---

## 6. Dados oficiais confirmados

```js
export const CFG = {
  whatsapp: '5598991123521',
  whatsDisplay: '(98) 99112-3521',
  phone: '(98) 2106-9100',
  phoneHref: 'tel:+559821069100',
  instagram: 'ioaitcsaoluis',
  street: 'R. Carutapera, 5 – Jardim Renascença',
  city: 'São Luís – MA · CEP 65075-670',
  mapsQuery: 'R. Carutapera, 5, Jardim Renascença, São Luís - MA, 65075-670'
};
```

**Clínica IOA, 11 serviços (folder):** Implante dentário · Ortodontia · Tratamento de canal · Restaurações estéticas · Cirurgia gengival · Coroas de porcelana · Lentes de contato dental · Prótese dentária · Cirurgia e extração dental · Botox · Harmonização facial. Chamada: "Agende sua avaliação gratuita".

**Rede IOA (informado pela instituição):** 41 unidades · 450 cursos · 17.000 alunos · 97.000 pacientes · 12 estados. Mostrar como números da **rede**, nunca da unidade.

**Textos institucionais confirmados**
- Quem somos (story): "Bem-vindos ao IOA/ITC São Luís: duas frentes de formação avançada em uma só instituição. Aqui, reunimos a maior Rede Premium em Educação Orofacial e o maior Instituto de Treinamento em Cadáveres Frescos das Américas. Uma estrutura pensada para profissionais da saúde que buscam ensino de alto nível, prática, tecnologia e evolução profissional."
- Estrutura (story): "Nossa unidade conta com infraestrutura de ponta, salas de aula, laboratórios, centro cirúrgico, equipamentos modernos e ambientes preparados para uma aprendizagem prática, segura e alinhada às exigências da área da saúde. A tecnologia faz parte da experiência IOA/ITC São Luís."
- Localização (story): "O IOA/ITC São Luís está localizado no Jardim Renascença, em uma unidade preparada para receber profissionais da saúde que buscam formação avançada, prática e atualização profissional."
- ITC: "Treinamentos avançados com cadáveres frescos para profissionais da saúde. Estudo de vasos, nervos, músculos, planos anatômicos e áreas de atenção."
- Chamada das especializações (stories): "Comece 2026 investindo na sua carreira profissional" e "Venha para o IOA ITC São Luís e especialize-se com quem é referência na área". Usar sem o "2026" fixo (ver seção 8).
- Certificação: "Os cursos de pós-graduação lato sensu e especializações do IOA contam com certificação e parcerias com instituições credenciadas ao MEC e ao CFO."
- Trajetória: aula pioneira de Anatomia Avançada em 2023; calendário anunciado pela Ceuma em agosto de 2024.
- Missão, visão e valores do IOA (humanização, evolução contínua e inovação, democratização da educação).
- Coordenação (publicar só com autorização, selo "sujeito a autorização"): Prof. Dr. José Márcio Soares Leite, assessor de Assuntos Especiais do Grupo Educacional Ceuma; Medicina (UFMA, 1973), mestrado (UFMA, 2001) e doutorado (UnB, 2010) em Ciências da Saúde; ex-Secretário Municipal de Saúde de São Luís e ex-Secretário de Estado da Saúde do Maranhão.

---

## 7. Mapa do site

### 7.1 `index.html`
1. **Hero** com `fachada-noturna.jpg` e overlay navy: kicker "IOA · ITC · Universidade Ceuma", título "Formação avançada em saúde orofacial, com prática real", subtítulo curto, CTAs "Ver especializações" e "Conhecer a estrutura".
2. **Quatro caminhos** (cartões): Especializações · Treinamento ITC · Estrutura · Clínica IOA.
3. **Quem somos** (texto do story) com `recepcao.jpg`.
4. **Especializações** (6 cards a partir de `data.js`, com área e "Consulte turmas e valores").
5. **Números da rede** (contador animado, nota "informados pela instituição, referem-se à rede IOA").
6. **Bloco ITC** (verde): texto oficial, chips (Vasos, Nervos, Músculos, Planos anatômicos, Áreas de atenção), `laboratorio-itc.jpg`.
7. **Prévia da estrutura:** 4 fotos em mosaico e botão "Ver toda a estrutura".
8. **Faixa dourada da clínica** com CTA de avaliação gratuita.
9. **Localização:** pílula dourada com o endereço, botão "Como chegar" (Google Maps).
10. **Formulário "Receba informações sobre as turmas"**.

### 7.2 `especializacoes.html`
- Busca por texto (sem acento).
- Filtro por **Área** (Endodontia, Radiologia, Dentística, Periodontia, Harmonização Orofacial, Odontopediatria, Ortodontia, Prótese Dentária), com contagem. Um curso pode ter mais de uma área.
- Ordenação alfabética ou "mais procurados" (ordem de `data.js`).
- Estados: carregando (skeleton), resultados, **vazio** com "Limpar filtros" e "Fale com a equipe".
- Comparar até 3 especializações (barra fixa e modal). Linhas da comparação: Áreas, Público, Modalidade, Certificação, Valores, Turmas. Campos sem dado mostram "Consulte a equipe".
- Aceitar `?area=`; no mobile, filtros em painel inferior.

### 7.3 `especializacao.html?slug=...`
- Hero com tag da área e foto de sala de aula.
- Abas: **Visão geral** · **Para quem é** · **Docentes** (lista textual autorizada ou "A confirmar") · **Certificação** (frase oficial) · **Dúvidas**.
- Caixa lateral (fixa no desktop, barra fixa no mobile): "Valores e turmas: consulte a equipe", botão **"Quero me inscrever"** (abre o formulário qualificado, **sem pagamento**) e **"Falar no WhatsApp"** com mensagem pronta citando o curso.
- "Outras especializações" ao final. Slug inválido → página 404 amigável.
- **Sem** abas de programa por módulo, carga horária ou preço.

### 7.4 `estrutura.html` (NOVA)
- Cabeçalho "Nossa estrutura" com o texto oficial do story.
- **Filtros por categoria:** Todas · Fachada · Recepção · Laboratório ITC · Auditório · Salas de aula · Clínica · Espaços de apoio · Detalhes.
- **Galeria em grade** (masonry simples por CSS columns, ou grade com fotos verticais ocupando 2 linhas), com legenda curta por foto.
- **Lightbox** próprio: abrir ao clicar, setas anterior/próxima, `Esc` fecha, foco preso, swipe no mobile, contador "3 / 11", `aria-label` nos botões e retorno do foco.
- Faixa final: "Quer conhecer pessoalmente?" com WhatsApp e "Como chegar".
- Legendas permitidas: só descritivas ("Laboratório do ITC", "Auditório", "Clínica odontológica"). Não citar capacidade, metragem nem equipamentos específicos.
- Não afirmar que há "centro cirúrgico" nas fotos; o termo só aparece dentro do texto oficial citado.

### 7.5 `treinamento-itc.html`
Hero verde com `laboratorio-itc.jpg`; texto oficial do ITC; chips do que se estuda; `auditorio-itc.jpg`; aviso de **ética e respeito** ("Conteúdo sujeito a validação da instituição"); como participar (falar com a equipe, sem etapas inventadas); FAQ **apenas** com respostas já confirmadas (onde fica, como falar com a equipe, certificação conforme frase oficial).

### 7.6 `clinica.html`
Hero com `clinica-odonto-1.jpg`; grade dos **11 serviços** (clicar preenche o formulário); `cadeira-odonto.jpg` e `clinica-odonto-2.jpg`; formulário de avaliação gratuita (nome, WhatsApp, serviço, período) com a nota **"não informe dados de saúde neste formulário"**; contatos.

### 7.7 `institucional.html`
Três instituições; números da rede; missão, visão, valores; trajetória; coordenação com selo "sujeito a autorização"; fotos `recepcao.jpg` e `sala-reuniao.jpg`; nota de certificação.

### 7.8 `contato.html`
WhatsApp, telefone, Instagram, endereço, mapa incorporado e formulário. E-mail: não exibir até ser informado.

### 7.9 `privacidade.html`
Modelo LGPD (dados coletados, finalidade, compartilhamento, direitos) com aviso "texto jurídico a ser fornecido pela instituição". Encarregado "a informar".

### 7.10 `admin.html` e `404.html`
Ver seção 12; 404 amigável com botão ao início.

> **Portal do aluno:** não implementar tela de login nem abas simuladas. Apenas um item de menu "Portal do aluno · em breve" que abre um modal curto explicando que será uma fase futura, com WhatsApp.

---

## 8. Modelo de dados (`js/data.js`)

Seis especializações, extraídas das divulgações oficiais da unidade (stories de 03/12/2025). **Nenhum campo de preço, datas ou carga horária.**

```js
export const COURSES = [{
  slug: 'endodontia-radiologia',
  title: 'Especializações em Endodontia e Radiologia',
  areas: ['endodontia', 'radiologia'],
  type: 'Especialização',
  audience: ['Cirurgiões-dentistas'],
  modality: 'Presencial · IOA/ITC São Luís',
  summary: 'Especializações em Endodontia e em Radiologia oferecidas pelo IOA/ITC São Luís.',
  docentes: [],                         // nomes não legendados no material
  source: 'Divulgação oficial @ioaitcsaoluis (03/12/2025)'
}, ...];
```

| slug | Título | Áreas | Observação |
|---|---|---|---|
| `endodontia-radiologia` | Especializações em Endodontia e Radiologia | endodontia, radiologia | dois cursos na mesma divulgação; docentes sem nome legendado |
| `dentistica-periodontia` | Especializações em Dentística e Periodontia · Estética branca e vermelha | dentística, periodontia | docentes: Dr. Darlon Martins, Dr. Fernando Fialho, Dr. Bruno Benatti |
| `harmonizacao-orofacial` | Especialização em Harmonização Orofacial | harmonização orofacial | docentes: Profa. Raizza Leite, Prof. Me. Carlos Eduardo Santos, Profa. Ma. Leonarda Tavares |
| `odontopediatria` | Especialização em Odontopediatria | odontopediatria | docentes: Prof. Dr. Silas Alves, Profa. Dra. Lorena Ladeira, Profa. Dra. Cláudia Rizzi, Profa. Dra. Anice Mohana, Profa. Dra. Clarissa Vieira |
| `ortodontia` | Especialização em Ortodontia | ortodontia | cinco docentes na divulgação, sem nomes legendados |
| `protese-periodontia-reabilitacao` | Especializações em Prótese Dentária e Periodontia · Reabilitação Oral Complexa | prótese dentária, periodontia | docentes: Eunice Umeda, José Ricardo Kina, Renata Baleeiro |

**Regras**
- O campo `docentes` guarda **só o nome e o título** e fica atrás da flag `CFG.mostrarDocentes = false`. Com a flag desligada, a aba mostra "Corpo docente: consulte a equipe". Ligar só quando a instituição autorizar. Não incluir fotos nem número de registro profissional.
- O texto de `summary` deve se limitar ao que os materiais dizem. Sem objetivos, programa ou "o que você vai aprender" inventados.
- `status` de inscrição **não existe**. Mostrar "Consulte turmas e valores".
- A divulgação é de dezembro de 2025 para 2026: se a turma ainda estiver aberta é informação da equipe. Não escrever "inscrições abertas".
- Tudo que aparece do curso é renderizado a partir de `data.js` (simula o CMS).
- O ITC (cadáveres frescos) é uma **frente de treinamento**, não um curso com preço. Não cadastrar cursos de Medicina ou de anatomia com título inventado.

---

## 9. Formulários e qualificação

### 9.1 Formulários
| Id | Onde | Campos |
|---|---|---|
| `interesse` | Início, especialização, modal "Avise-me" | nome, WhatsApp, e-mail, perfil, área de interesse |
| `qualificado` | "Quero me inscrever" | nome, WhatsApp, e-mail, perfil, registro (CRO/CRM/CRBM, opcional), especialização, prazo, modalidade |
| `clinica` | Clínica | nome, WhatsApp, serviço, período |
| `contato` | Contato | nome, e-mail, WhatsApp, assunto, mensagem |

Perfis: Cirurgião-dentista · Médico · Biomédico · Estudante · Outro.

### 9.2 Comportamento
- Validação ao enviar e ao sair do campo, mensagem junto ao campo, `aria-invalid`, foco no primeiro erro.
- Máscara `(98) 90000-0000`, exigindo DDD.
- Checkbox LGPD obrigatório com link para a política.
- Estados: enviando (spinner e botão desabilitado), **sucesso** (mensagem + "Agilizar pelo WhatsApp" com texto pronto) e **erro** (alternativa via WhatsApp).
- Atraso simulado de ~1 s; painel pode forçar erro.
- Cada envio vira um lead em `localStorage` (`ioa_leads`): `id`, `tipo`, dados, `origem`, `curso`, `qualificacao`, `data`.
- Nenhum dado é enviado a servidor externo.

### 9.3 Qualificação (regras a validar com o comercial)
Aplicada ao formulário `qualificado`. Pontuação simples e explicável:

| Critério | Pontos |
|---|---|
| Perfil elegível para a especialização (conforme `audience`) | +3 |
| Informou registro profissional | +2 |
| Pretende iniciar em até 3 meses | +3 |
| Pretende iniciar em 3 a 6 meses | +1 |
| Consegue participar presencialmente em São Luís | +2 |
| "Só pesquisando" | 0 |

- **≥ 7 → Qualificado:** botão de WhatsApp com mensagem pronta (nome, curso, perfil).
- **3 a 6 → Em nutrição:** sem WhatsApp imediato; entra na lista.
- **< 3 ou perfil fora do curso → Fora do perfil:** mensagem educada com cursos compatíveis.

A pontuação nunca aparece para o visitante; a classificação aparece só no painel. Deixar a tabela em `config.js` para ajustar fácil.

---

## 10. Chatbot por regras (`js/chatbot.js`)

- Botão flutuante "Atendimento" (só ícone no mobile); janela com histórico, respostas rápidas, campo de texto e botão **"Continuar com um atendente no WhatsApp"**; indicador de digitação (~650 ms).
- **Intenções** (normalizar acentos e caixa): cadáveres/ITC, especializações/cursos (lista as 6), estrutura/fotos, clínica/avaliação/serviços, endereço/localização, certificação/MEC/CFO, valores/parcelamento, datas/turmas/inscrição, docentes, atendente/humano, saudação.
- **Valores, datas, vagas e carga horária:** responder "essas informações são passadas pela equipe" e oferecer o WhatsApp. **Nunca inventar números.**
- **Fallback:** "Ainda não sei responder isso com segurança" + botão de atendente.
- **Handoff:** o link `wa.me` leva as **3 últimas perguntas** como texto.
- `Esc` fecha; foco gerenciado; `aria-live` na lista de mensagens.

---

## 11. Navegação e componentes globais

- **Header** fixo: logo, menu (Início, Especializações, Treinamento ITC, **Estrutura**, Clínica, Institucional, Contato), botão "Falar no WhatsApp". Item discreto "Portal do aluno · em breve".
- **Menu mobile** em tela cheia, foco preso e `Esc`.
- **Barra de ações fixa no mobile:** Especializações · Estrutura · WhatsApp.
- **Rodapé:** logo em placa branca, navegação, áreas, contatos, Instagram, política, "Razão social e CNPJ: a informar", nota "Protótipo acadêmico · conteúdo sujeito a validação pela instituição".
- Todo botão e link tem ação real. Nada de `href="#"`.

---

## 12. Painel simulado (`admin.html`)

Substitui CMS e CRM nesta versão. `noindex`. Aviso visível: "Painel de demonstração. Os dados ficam só neste navegador." **Sem login real e sem pedir senha.**

- **Leads:** tabela (data, tipo, nome, contato, curso, origem, qualificação), filtros, **exportar CSV**, **limpar leads**.
- **Especializações:** lista editável (título, resumo, áreas), salva em `localStorage` e usada pelo site no lugar de `data.js`. Botões "Restaurar padrão" e "Exportar JSON".
- **Fotos da galeria:** lista com ordem e legenda editáveis (simulação).
- **Alternadores de demonstração:** "simular erro no próximo envio" e "simular catálogo vazio".
- **Resumo:** leads por origem e por curso (barras em CSS).

---

## 13. Responsividade

Mobile first, quebras em **600, 900 e 1080 px**. O mobile não é o desktop reduzido:
- menu em tela cheia, barra de ações fixa, filtros em painel inferior;
- botão de inscrição fixo na página da especialização;
- galeria em 1 coluna (até 600 px) e 2 colunas (600–900 px), lightbox em tela cheia com swipe;
- tipografia fluida (`clamp`), alvos de toque ≥ 44 px, `safe-area-inset-bottom`;
- sem rolagem horizontal de 320 a 1920 px.

---

## 14. Acessibilidade, SEO, desempenho e LGPD

**Acessibilidade (WCAG 2.1 AA):** HTML semântico, um `h1` por página, "Pular para o conteúdo", foco visível, teclado completo, modais e lightbox com foco preso e retorno do foco, `label` em todos os campos, `aria-live` em erros e sucesso, `alt` descritivo, contraste ≥ 4,5:1, `prefers-reduced-motion`.

**SEO:** `title` e `meta description` únicos (dinâmicos nas especializações), Open Graph (imagem: `fachada-noturna.jpg`), `lang="pt-BR"`, favicon, JSON-LD `EducationalOrganization` (com endereço e telefone reais) e `Course` na página da especialização (sem preço), `sitemap.xml`, `robots.txt` (admin `noindex`). Termos naturais: "especialização em ortodontia em São Luís", "harmonização orofacial São Luís", "clínica odontológica no Jardim Renascença".

**Desempenho:** sem bibliotecas pesadas; imagens já otimizadas (≤ 1600 px), `loading="lazy"`, fonte com `display=swap`; Lighthouse alvo: Acessibilidade e SEO ≥ 90, Desempenho ≥ 85 no mobile.

**LGPD:** consentimento explícito e finalidade em cada formulário, só o necessário, **sem dados de saúde**, política acessível, dados só em `localStorage` com botão para limpar.

---

## 15. Critérios de aceite

- [ ] Todas as páginas abrem sem erro no console e sem link quebrado.
- [ ] Nenhum botão sem ação.
- [ ] **Nenhum preço, data, carga horária, vaga, depoimento ou número da unidade aparece em lugar algum.**
- [ ] As 6 especializações aparecem corretamente no catálogo, filtro por área, comparação e página própria.
- [ ] Estrutura: as 11 fotos aparecem, filtram por categoria e abrem no lightbox com teclado e swipe.
- [ ] Formulários validam, aplicam máscara, exigem LGPD e mostram carregando, sucesso e erro.
- [ ] Qualificação classifica os três cenários e o painel mostra o resultado.
- [ ] Chatbot responde às intenções, nunca inventa valores e faz handoff com contexto.
- [ ] Docentes ocultos por padrão (`mostrarDocentes = false`) e sem fotos de pessoas no site.
- [ ] Dados de contato idênticos à seção 6.
- [ ] Sem rolagem horizontal de 320 a 1920 px; mobile com menu, barra de ações e filtros próprios.
- [ ] Teclado completo e contraste conferido; Lighthouse nas metas.

---

## 16. Cuidados

- O WhatsApp de `config.js` é **real**: o clique abre conversa de verdade. Para testar, trocar por um número seu.
- Não publicar com nome e marca do IOA/ITC sem aprovação da instituição.
- Sem credenciais, chaves ou dados pessoais reais no código.
- Fotos: usar só as de `assets/img/`. Não baixar imagens da internet.
- Os nomes dos docentes e a lista das 6 especializações vêm de posts públicos de dezembro de 2025. Confirmar com a instituição se continuam vigentes antes de qualquer uso real.

---

## 17. Ordem de trabalho para o Claude Code

Trabalhar em etapas e **parar ao fim de cada uma**.

1. **Base:** pastas, `tokens.css`, `base.css`, `config.js`, `data.js`, `layout.js` e uma `index.html` mínima.
2. **Início completo** (7.1) e componentes (botões, cards, contadores, animações).
3. **Estrutura** (7.4): galeria, filtros e lightbox.
4. **Catálogo e página da especialização** (7.2 e 7.3), com comparação.
5. **Formulários, qualificação e leads** (seção 9).
6. **Chatbot** (seção 10).
7. **Páginas restantes:** ITC, clínica, institucional, contato, privacidade, 404 e modal "em breve".
8. **Painel simulado** (seção 12).
9. **Acessibilidade, SEO, desempenho e testes** (13 a 15), em 390 px e 1366 px.
10. **README.md:** como rodar (Live Server), estrutura, o que é simulado, como trocar para backend real e pendências de conteúdo.

### Prompt inicial (cole no Claude Code)
> Leia `SPEC-site-ioa-itc.md` por inteiro. As fotos estão em `assets/img/` e o protótipo antigo em `referencia/` (use só como referência visual; ele tem dados inventados que não podem ser copiados). Implemente a **etapa 1**, sem frameworks e sem build. Não invente nenhum dado institucional: sem preços, datas, carga horária ou vagas. Ao terminar, liste o que criou e espere minha aprovação para a etapa 2.
